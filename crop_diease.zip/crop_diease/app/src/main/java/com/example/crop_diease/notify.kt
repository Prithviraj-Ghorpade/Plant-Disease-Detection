package com.example.crop_diease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class notify : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notify)
    }
}